from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, TextAreaField
from wtforms.validators import InputRequired, Email, Length, EqualTo

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=4, max=100)])
    password = PasswordField('Password', validators=[InputRequired(), Length(min=4, max=100)])
    role = SelectField('Login as', choices=[('volunteer', 'Volunteer'), ('company', 'Company')])
    submit = SubmitField('Login')

class SignupForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=4, max=100)])
    email = StringField('Email', validators=[InputRequired(), Email()])
    password = PasswordField('Password', validators=[InputRequired(), Length(min=4, max=100), EqualTo('confirm', message='Passwords must match')])
    confirm = PasswordField('Confirm Password')
    submit = SubmitField('Sign Up')

class OpportunityForm(FlaskForm):
    title = StringField('Title', validators=[InputRequired(), Length(max=200)])
    description = TextAreaField('Description', validators=[InputRequired(), Length(max=500)])
    category = SelectField('Category', choices=[('environment', 'Environment'), ('education', 'Education'), ('health', 'Health')])
    submit = SubmitField('Create Opportunity')
